export interface IAutenticavel {
  id: string
  email: string
  senha: string
}
